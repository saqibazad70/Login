﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Signup.Models
{
    public class Register
    {

        [Display(Name = "Enter Your Name")]
        [Required(ErrorMessage = "Please enter your Name")]
        public string Name { get; set; }

        [Display(Name = "Enter Father name")]
        [Required(ErrorMessage = "Please Enter Father Name")]
        public string fname { get; set; }

        [Display(Name = "Enter Email")]
        public string email { get; set; }

        [Display(Name = "Enter mobile")]
        public string mobile { get; set; }

        [Display(Name = "Enter password")]
        public string password { get; set; }
    }
}