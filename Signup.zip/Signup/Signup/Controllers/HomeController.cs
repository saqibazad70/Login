﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using Signup.Models;

namespace Signup.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Signup()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Signup(Register s)
        {
            if(ModelState.IsValid)
            {
                string Saqib ="Insert into data values('"+s.Name+"','"+s.fname+"','"+s.email+"','"+s.mobile+"','"+s.password+"','"+DateTime.Now.ToString()+"')";
                SqlConnection con = new SqlConnection("Data Source=LAPTOP-V0D39CBE\\SQLEXPRESS; Initial Catalog=signup;Integrated Security=true");
                if (con.State==ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand(Saqib, con);
                int a = cmd.ExecuteNonQuery();
                if(a>0)
                {
                    ViewBag.msg = "Data Inserted";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.msg = "Server error";
                }
            }
            else
            {
                ViewBag.msg = "Please Check Model";
            }
            return View();
        }

    }
}
